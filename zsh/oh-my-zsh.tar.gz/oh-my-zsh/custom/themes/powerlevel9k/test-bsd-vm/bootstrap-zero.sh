#!/bin/sh

pkg install -y sudo